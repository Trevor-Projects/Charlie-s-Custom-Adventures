import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Google GenAI
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Helper function to call Wikipedia API for article summaries and thumbnails
async function fetchWikipediaSummary(title: string) {
  try {
    const cleanTitle = encodeURIComponent(title.trim().replace(/ /g, "_"));
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${cleanTitle}`;
    const res = await fetch(url, {
      headers: { "User-Agent": "DND5EMythicQuestGenerator/1.0 (contact@example.com)" },
    });
    if (!res.ok) return null;
    const data = await res.json();
    return {
      title: data.title,
      extract: data.extract,
      description: data.description,
      thumbnail: data.thumbnail?.source || null,
      originalImage: data.originalimage?.source || null,
      contentUrl: data.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${cleanTitle}`,
    };
  } catch (error) {
    console.error("Wikipedia fetch error:", error);
    return null;
  }
}

// Helper to search Wikipedia
async function searchWikipedia(query: string) {
  try {
    const cleanQuery = encodeURIComponent(query);
    const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${cleanQuery}&format=json&origin=*&srlimit=5`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    const results = data?.query?.search || [];
    return results.map((item: any) => ({
      title: item.title,
      snippet: item.snippet.replace(/<[^>]*>?/gm, ""), // strip HTML
      pageid: item.pageid,
    }));
  } catch (error) {
    console.error("Wikipedia search error:", error);
    return [];
  }
}

// --- API ROUTES ---

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

// Search Wikipedia
app.get("/api/wikipedia/search", async (req, res) => {
  const query = (req.query.q as string) || "";
  if (!query) {
    return res.json({ results: [] });
  }
  const results = await searchWikipedia(query);
  res.json({ results });
});

// Fetch Wikipedia summary and main image
app.get("/api/wikipedia/summary", async (req, res) => {
  const title = (req.query.title as string) || "";
  if (!title) {
    return res.status(400).json({ error: "Title parameter required" });
  }
  const summary = await fetchWikipediaSummary(title);
  if (!summary) {
    return res.status(404).json({ error: "Article not found" });
  }
  res.json(summary);
});

// Fetch batch Wikipedia inspirations (e.g. for world building)
app.post("/api/wikipedia/inspirations", async (req, res) => {
  const { topics } = req.body;
  if (!Array.isArray(topics)) {
    return res.status(400).json({ error: "Topics array required" });
  }
  const promises = topics.slice(0, 4).map((topic: string) => fetchWikipediaSummary(topic));
  const results = await Promise.all(promises);
  const validInspirations = results.filter(Boolean);
  res.json({ inspirations: validInspirations });
});

function getPronounsStr(gender?: string) {
  if (gender === 'Male') return 'he/him';
  if (gender === 'Female') return 'she/her';
  return 'they/them';
}

// Generate Adventure / Campaign Opening
app.post("/api/gemini/generate-adventure", async (req, res) => {
  try {
    if (!ai) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured in environment variables.",
      });
    }

    const {
      party, // Array of 1-3 characters
      setting, // Setting preset or custom name
      scenarioHook, // Initial starting hook choice
      wikiTopics, // Selected Wikipedia inspiration topics
      customNotes,
    } = req.body;

    const partySummary = party
      .map(
        (p: any, i: number) =>
          `Player ${i + 1} (${p.playerName}): ${p.name}, Gender: ${p.gender || "I'd rather not say"} (Pronouns: ${getPronounsStr(p.gender)}), ${p.race} ${p.characterClass} (Level 1, HP: ${p.hp}/${p.maxHp}, AC: ${p.ac}, STR ${p.stats.str}, DEX ${p.stats.dex}, CON ${p.stats.con}, INT ${p.stats.int}, WIS ${p.stats.wis}, CHA ${p.stats.cha}) - Backstory: ${p.backstory || "Eager for adventure"}`
      )
      .join("\n");

    const prompt = `You are an expert, immersive Dungeons & Dragons 5th Edition Dungeon Master (DM).
Create a captivating campaign opening for a 1 to 4 player party.

WORLD SETTING / THEME: ${setting || "Fantasy Realm"}
STARTING HOOK: ${scenarioHook || "A mysterious artifact discovered in ancient ruins"}
WIKIPEDIA REAL-WORLD INSPIRATIONS: ${wikiTopics && wikiTopics.length > 0 ? wikiTopics.join(", ") : "Ancient Silk Road trade, Byzantine architecture, Celtic myth"}
CUSTOM NOTES: ${customNotes || "None"}

PARTY MEMBERS:
${partySummary}

STRICT PRONOUN DIRECTIVE:
When describing actions or referring to any character in the story, you MUST strictly use their designated pronouns:
- Male -> he/him/his
- Female -> she/her/hers
- "I'd rather not say" -> they/them/their

Your task:
1. Construct a rich fantasy campaign world, referencing real-world cultural, historical, or linguistic elements drawn from the provided Wikipedia inspiration topics.
2. Formulate 4 milestone objectives for the entire campaign (Chapter 1: The Inciting Incident, Chapter 2: The Deepening Shadow, Chapter 3: The Turning Point, Chapter 4: The Final Confrontation).
3. Write an evocative 3-paragraph opening narrative setting the stage, introducing the world, where the heroes are, and what immediate situation they face. Make sure to refer to the characters using their specified pronouns!
4. Present 3 to 4 distinct player action choices. Each choice must specify which D&D 5E skill check or combat action applies (e.g. "Investigate the arcane glyphs [Arcana DC 12]", "Force open the rusted iron gate [Athletics DC 14]", "Inquire quietly with the tavern keeper [Persuasion DC 11]", or "Prepare weapons for immediate battle [Initiative / Combat]").
5. Provide 2-3 specific real Wikipedia topic search terms (e.g., "Minoan civilization", "Byzantine siegecraft", "Celtic hillfort") that fit this fantasy scene so we can display real historical imagery and lore.

Format your response strictly as JSON with this schema:
{
  "worldName": "string",
  "worldSummary": "string",
  "historicalInspirations": [
    { "topic": "string", "relevance": "string" }
  ],
  "milestones": [
    { "chapter": 1, "title": "string", "description": "string", "completed": false },
    { "chapter": 2, "title": "string", "description": "string", "completed": false },
    { "chapter": 3, "title": "string", "description": "string", "completed": false },
    { "chapter": 4, "title": "string", "description": "string", "completed": false }
  ],
  "openingScene": "string (multiline narrative)",
  "activePlayerIndex": 0,
  "choices": [
    {
      "id": "choice_1",
      "text": "string description of action",
      "statReq": "str | dex | con | int | wis | cha | combat | none",
      "skillName": "Athletics | Stealth | Arcana | History | Perception | Insight | Persuasion | Deception | Intimidation | Medicine | Survival | Religion | Combat | Attack",
      "dc": 12
    }
  ],
  "wikiSearchKeywords": ["string"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            worldName: { type: Type.STRING },
            worldSummary: { type: Type.STRING },
            historicalInspirations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  topic: { type: Type.STRING },
                  relevance: { type: Type.STRING },
                },
              },
            },
            milestones: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  chapter: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  completed: { type: Type.BOOLEAN },
                },
              },
            },
            openingScene: { type: Type.STRING },
            activePlayerIndex: { type: Type.INTEGER },
            choices: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  text: { type: Type.STRING },
                  statReq: { type: Type.STRING },
                  skillName: { type: Type.STRING },
                  dc: { type: Type.INTEGER },
                },
              },
            },
            wikiSearchKeywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: [
            "worldName",
            "worldSummary",
            "historicalInspirations",
            "milestones",
            "openingScene",
            "activePlayerIndex",
            "choices",
            "wikiSearchKeywords",
          ],
        },
      },
    });

    const jsonText = response.text || "{}";
    const data = JSON.parse(jsonText);

    // Automatically fetch real Wikipedia thumbnails for the search keywords
    const keywords = data.wikiSearchKeywords || [];
    const wikiCardPromises = keywords.slice(0, 3).map((kw: string) => fetchWikipediaSummary(kw));
    const wikiCards = (await Promise.all(wikiCardPromises)).filter(Boolean);

    res.json({
      ...data,
      wikiCards,
    });
  } catch (error: any) {
    console.error("Error generating adventure:", error);
    res.status(500).json({ error: error.message || "Failed to generate adventure." });
  }
});

// Process Turn / Player Action
app.post("/api/gemini/next-turn", async (req, res) => {
  try {
    if (!ai) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured in environment variables.",
      });
    }

    const {
      worldName,
      currentMilestoneIndex,
      milestones,
      party,
      activePlayerIndex,
      actionChosen, // string text or custom action
      diceRoll, // { stat: 'str', skill: 'Athletics', d20: 15, modifier: 3, total: 18, dc: 14, isSuccess: true, isCrit: false, isFail: false }
      historySummary, // last few turn narrative snippets
    } = req.body;

    const activePlayer = party[activePlayerIndex] || party[0];
    const currentMilestone = milestones[currentMilestoneIndex] || milestones[0];

    const partyState = party
      .map(
        (p: any, i: number) =>
          `P${i + 1} (${p.playerName}): ${p.name} (${p.race} ${p.characterClass}, Gender: ${p.gender || "I'd rather not say"}, Pronouns: ${getPronounsStr(p.gender)}) - HP: ${p.hp}/${p.maxHp}, Spell Slots: ${p.spellSlots ?? 0}/${p.maxSpellSlots ?? 0}, Status Effects: ${
            p.statusEffects && p.statusEffects.length > 0 ? p.statusEffects.join(', ') : 'None'
          }`
      )
      .join("; ");

    const prompt = `You are a D&D 5th Edition Dungeon Master managing an ongoing adventure in world: "${worldName}".
CURRENT CHAPTER / MILESTONE: Chapter ${currentMilestone.chapter}: "${currentMilestone.title}" - Goal: ${currentMilestone.description}
PARTY STATUS: ${partyState}
ACTING PLAYER: ${activePlayer.name} (${activePlayer.race} ${activePlayer.characterClass}, Player ${activePlayerIndex + 1}, Gender: ${activePlayer.gender || "I'd rather not say"}, Pronouns: ${getPronounsStr(activePlayer.gender)})

PLAYER ACTION TAKEN: "${actionChosen}"
${
  diceRoll
    ? `DICE ROLL RESULT: rolled a natural d20 of ${diceRoll.d20} + modifier ${diceRoll.modifier} = TOTAL ${diceRoll.total} vs DC ${diceRoll.dc}. RESULT: ${diceRoll.isSuccess ? "SUCCESS!" : "FAILURE!"} ${diceRoll.isCrit ? "CRITICAL HIT / NATURAL 20!" : ""} ${diceRoll.isFail ? "CRITICAL MISS / NATURAL 1!" : ""}`
    : "NO ROLL SPECIFIED (Direct / Story Action)"
}

RECENT NARRATIVE HISTORY:
${historySummary || "The journey has just begun."}

STRICT PRONOUN DIRECTIVE:
You MUST refer to each character using their designated pronouns throughout the narrative:
- Male -> he/him/his
- Female -> she/her/hers
- "I'd rather not say" -> they/them/their

Tasks:
1. Write 2-3 detailed, immersive paragraphs describing the consequences of ${activePlayer.name}'s action and roll outcome. Always refer to ${activePlayer.name} using ${getPronounsStr(activePlayer.gender)} pronouns! Incorporate D&D 5E combat details or skill outcomes seamlessly.
2. Determine if this turn advances or completes the current campaign milestone (set 'milestoneCompleted: true' if this chapter's objective was achieved!).
3. Update party HP, spell slots, inventory, or temporary status effects (such as 'Poisoned', 'Stunned', 'Inspired', 'Blessed', 'Charmed', 'Blinded', 'Frightened', 'Restrained', 'Hasted', 'Shielded').
4. Check if a Combat Encounter should begin. If yes, set 'isCombat: true' and populate monster details (name, hp, ac, attacks).
5. Pass turn to the next player (activePlayerIndex should cycle between 0 and ${party.length - 1}).
6. Generate 3 to 4 distinct choice options for the next acting player.
7. Provide 1-2 Wikipedia search terms for cultural, architectural, or historical imagery inspired by this scene.

Return strictly JSON matching this schema:
{
  "narrative": "string",
  "activePlayerIndex": 0,
  "milestoneCompleted": false,
  "hpChanges": [
    { "playerIndex": 0, "deltaHp": -3, "reason": "Trap needle" }
  ],
  "statusChanges": [
    { "playerIndex": 0, "addEffects": ["Poisoned"], "removeEffects": [] }
  ],
  "itemsGained": ["Health Potion", "Ancient Silver Coin"],
  "isCombat": false,
  "combatEncounter": {
    "enemyName": "string",
    "enemyHp": 20,
    "maxEnemyHp": 20,
    "enemyAc": 13,
    "enemyAttackBonus": 3,
    "enemyDamage": "1d6+2 Slashing",
    "description": "string"
  },
  "choices": [
    {
      "id": "choice_1",
      "text": "string description",
      "statReq": "str | dex | con | int | wis | cha | combat | none",
      "skillName": "Athletics | Stealth | Arcana | Perception | Persuasion | Attack",
      "dc": 12
    }
  ],
  "wikiSearchKeywords": ["string"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING },
            activePlayerIndex: { type: Type.INTEGER },
            milestoneCompleted: { type: Type.BOOLEAN },
            hpChanges: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  playerIndex: { type: Type.INTEGER },
                  deltaHp: { type: Type.INTEGER },
                  reason: { type: Type.STRING },
                },
              },
            },
            itemsGained: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            isCombat: { type: Type.BOOLEAN },
            combatEncounter: {
              type: Type.OBJECT,
              properties: {
                enemyName: { type: Type.STRING },
                enemyHp: { type: Type.INTEGER },
                maxEnemyHp: { type: Type.INTEGER },
                enemyAc: { type: Type.INTEGER },
                enemyAttackBonus: { type: Type.INTEGER },
                enemyDamage: { type: Type.STRING },
                description: { type: Type.STRING },
              },
            },
            choices: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  text: { type: Type.STRING },
                  statReq: { type: Type.STRING },
                  skillName: { type: Type.STRING },
                  dc: { type: Type.INTEGER },
                },
              },
            },
            wikiSearchKeywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
          },
          required: [
            "narrative",
            "activePlayerIndex",
            "milestoneCompleted",
            "choices",
            "wikiSearchKeywords",
          ],
        },
      },
    });

    const jsonText = response.text || "{}";
    const data = JSON.parse(jsonText);

    // Fetch Wikipedia thumbnails
    const keywords = data.wikiSearchKeywords || [];
    const wikiCardPromises = keywords.slice(0, 2).map((kw: string) => fetchWikipediaSummary(kw));
    const wikiCards = (await Promise.all(wikiCardPromises)).filter(Boolean);

    res.json({
      ...data,
      wikiCards,
    });
  } catch (error: any) {
    console.error("Error processing next turn:", error);
    res.status(500).json({ error: error.message || "Failed to process turn." });
  }
});

// API Route: Journal Summarizer (Chronicle Generator)
app.post("/api/summarize-journal", async (req, res) => {
  try {
    if (!ai) {
      return res.status(500).json({ error: "Gemini API key is not configured on the server." });
    }

    const { worldName, worldSummary, party, history, milestones } = req.body;

    const historySummary = history
      .map(
        (t: any, i: number) =>
          `[Turn ${i + 1} - ${t.activePlayerName || "Party"}] Action: ${t.actionText || "Initiated"}. Narrative: ${t.narrative}`
      )
      .join("\n\n");

    const partySummary = party
      .map((p: any) => `${p.name} (${p.race} ${p.characterClass})`)
      .join(", ");

    const prompt = `You are a master royal chronicler and bard recording the grand saga of a D&D 5E party.
Synthesize the provided turn history log into a beautifully written, structured adventure journal chronicle.

WORLD: ${worldName || "The Mythic Realm"} (${worldSummary || ""})
HEROES: ${partySummary}
MILESTONES / CHAPTERS: ${JSON.stringify(milestones || [])}

HISTORY LOG:
${historySummary}

Your task:
1. Provide an epic title for this chronicle volume.
2. Write a 2-paragraph overarching narrative chronicle of the journey so far.
3. Group the story beats into structured chapters or narrative arcs. For each arc, include a chapter title, narrative prose summary, key highlights/achievements, and an atmospheric hero quote or motto.
4. Conclude with a brief heroic evaluation of the party's legacy and standing.

Format your response strictly as JSON with this schema:
{
  "title": "string",
  "overallChronicle": "string",
  "storyBeats": [
    {
      "beatNumber": 1,
      "chapterTitle": "string",
      "summary": "string",
      "keyHighlights": ["string"],
      "heroicQuote": "string"
    }
  ],
  "partyLegacy": "string"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            overallChronicle: { type: Type.STRING },
            storyBeats: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  beatNumber: { type: Type.INTEGER },
                  chapterTitle: { type: Type.STRING },
                  summary: { type: Type.STRING },
                  keyHighlights: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  heroicQuote: { type: Type.STRING },
                },
                required: ["beatNumber", "chapterTitle", "summary", "keyHighlights"],
              },
            },
            partyLegacy: { type: Type.STRING },
          },
          required: ["title", "overallChronicle", "storyBeats", "partyLegacy"],
        },
      },
    });

    const jsonText = response.text || "{}";
    const data = JSON.parse(jsonText);
    res.json(data);
  } catch (error: any) {
    console.error("Error generating journal chronicle:", error);
    res.status(500).json({ error: error.message || "Failed to generate journal chronicle." });
  }
});

// Setup Vite or Static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`D&D 5E Mythic Quest Server running on http://localhost:${PORT}`);
  });
}

startServer();
