import React from 'react';
import {
  Shield,
  Heart,
  Sparkles,
  Info,
  Bot,
  Biohazard,
  Zap,
  Sun,
  EyeOff,
  AlertTriangle,
  Lock,
  Gauge,
  ShieldCheck,
  Activity,
} from 'lucide-react';
import { Character, StatusEffectType } from '../types';
import { formatModifier, getStatModifier, STATUS_EFFECTS_CONFIG } from '../data/presets';

interface PartyBarProps {
  party: Character[];
  activePlayerIndex: number;
  onSelectCharacter: (character: Character) => void;
}

export const getStatusEffectIcon = (effect: string) => {
  switch (effect) {
    case 'Poisoned':
      return <Biohazard className="w-3 h-3 text-emerald-400" />;
    case 'Stunned':
      return <Zap className="w-3 h-3 text-yellow-400" />;
    case 'Inspired':
      return <Sparkles className="w-3 h-3 text-amber-300" />;
    case 'Blessed':
      return <Sun className="w-3 h-3 text-cyan-300" />;
    case 'Charmed':
      return <Heart className="w-3 h-3 text-rose-400" />;
    case 'Blinded':
      return <EyeOff className="w-3 h-3 text-purple-400" />;
    case 'Frightened':
      return <AlertTriangle className="w-3 h-3 text-violet-400" />;
    case 'Restrained':
      return <Lock className="w-3 h-3 text-orange-400" />;
    case 'Hasted':
      return <Gauge className="w-3 h-3 text-teal-300" />;
    case 'Shielded':
      return <ShieldCheck className="w-3 h-3 text-blue-400" />;
    default:
      return <Activity className="w-3 h-3 text-amber-400" />;
  }
};

export const PartyBar: React.FC<PartyBarProps> = ({
  party,
  activePlayerIndex,
  onSelectCharacter,
}) => {
  return (
    <div className="bg-stone-900/90 border border-amber-900/40 rounded-2xl p-4 shadow-xl mb-6 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-3 border-b border-stone-800 pb-2">
        <h2 className="text-xs font-serif font-bold text-amber-200 uppercase tracking-wider flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          Active Adventuring Party ({party.length} {party.length === 1 ? 'Player' : 'Players'})
        </h2>
        <span className="text-[11px] text-stone-400">
          Turn Order: <strong className="text-amber-300">{party[activePlayerIndex]?.name}'s Turn</strong>
        </span>
      </div>

      <div
        className={`grid gap-3 ${
          party.length === 1
            ? 'grid-cols-1 max-w-md mx-auto'
            : party.length === 2
            ? 'grid-cols-1 sm:grid-cols-2'
            : party.length === 3
            ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3'
            : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
        }`}
      >
        {party.map((char, index) => {
          const isActive = index === activePlayerIndex;
          const hpPercentage = Math.max(0, Math.min(100, (char.hp / char.maxHp) * 100));

          let hpColor = 'bg-emerald-500';
          if (hpPercentage < 30) hpColor = 'bg-red-500 animate-pulse';
          else if (hpPercentage < 60) hpColor = 'bg-amber-500';

          return (
            <div
              key={char.id}
              onClick={() => onSelectCharacter(char)}
              className={`p-3 rounded-xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                isActive
                  ? 'bg-amber-950/60 border-amber-500 shadow-lg ring-2 ring-amber-500/30'
                  : 'bg-stone-950/70 border-stone-800 hover:border-stone-700 hover:bg-stone-950'
              }`}
            >
              {isActive && (
                <div className="absolute top-2 right-2 flex items-center gap-1 bg-amber-500 text-stone-950 px-2 py-0.5 rounded-full text-[10px] font-bold shadow-sm">
                  <Sparkles className="w-3 h-3" />
                  ACTIVE TURN
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 mb-2">
                  {char.portraitUrl ? (
                    <img
                      src={char.portraitUrl}
                      alt={char.name}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-lg object-cover border border-amber-500/70 shadow-sm bg-stone-900 flex-shrink-0"
                    />
                  ) : (
                    <span className="text-2xl p-1 bg-stone-900 rounded-lg border border-stone-800 flex-shrink-0">
                      {char.avatar}
                    </span>
                  )}
                  <div>
                    <div className="text-sm font-bold font-serif text-stone-100 flex items-center gap-1.5">
                      {char.name}
                      {char.isAiControlled ? (
                        <span className="text-[9px] px-1.5 py-0.2 bg-amber-950/80 text-amber-300 border border-amber-700/60 font-mono font-bold rounded flex items-center gap-0.5">
                          <Bot className="w-2.5 h-2.5 text-amber-400" />
                          AI
                        </span>
                      ) : null}
                      <Info className="w-3 h-3 text-stone-500 opacity-60 hover:opacity-100" />
                    </div>
                    <div className="text-[11px] text-stone-400">
                      {char.race} {char.characterClass} • Lvl {char.level}{' '}
                      <span className="text-[10px] text-amber-400/90 font-mono">
                        ({char.gender === 'Male' ? 'he/him' : char.gender === 'Female' ? 'she/her' : 'they/them'})
                      </span>
                    </div>
                  </div>
                </div>

                {/* HP Gauge */}
                <div className="mb-2">
                  <div className="flex justify-between text-[10px] font-semibold text-stone-300 mb-1">
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-red-400" />
                      Hit Points
                    </span>
                    <span>
                      {char.hp} / {char.maxHp}
                    </span>
                  </div>
                  <div className="w-full bg-stone-900 rounded-full h-2 overflow-hidden border border-stone-800">
                    <div
                      className={`h-full ${hpColor} transition-all duration-300`}
                      style={{ width: `${hpPercentage}%` }}
                    />
                  </div>
                </div>

                {/* Active Temporary Status Effects */}
                {char.statusEffects && char.statusEffects.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {char.statusEffects.map((eff) => {
                      const config = STATUS_EFFECTS_CONFIG[eff as StatusEffectType];
                      return (
                        <span
                          key={eff}
                          title={config ? config.description : eff}
                          className={`text-[10px] px-2 py-0.5 rounded-md font-semibold flex items-center gap-1 border shadow-sm ${
                            config
                              ? `${config.bgClass} ${config.textClass} ${config.borderClass}`
                              : 'bg-stone-900 text-stone-300 border-stone-800'
                          }`}
                        >
                          {getStatusEffectIcon(eff)}
                          {eff}
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Combat Stats Badges */}
              <div className="flex items-center justify-between text-[11px] pt-2 border-t border-stone-800/80 text-stone-300">
                <span className="flex items-center gap-1 font-mono font-medium">
                  <Shield className="w-3 h-3 text-amber-400" /> AC {char.ac}
                </span>

                {char.maxSpellSlots > 0 ? (
                  <span
                    className="text-purple-300 font-mono font-bold flex items-center gap-1"
                    title={`${char.spellSlots} of ${char.maxSpellSlots} spell slots available`}
                  >
                    <Sparkles className="w-3 h-3 text-purple-400" />
                    <span>{char.spellSlots}/{char.maxSpellSlots}</span>
                    <span className="flex gap-0.5">
                      {Array.from({ length: char.maxSpellSlots }).map((_, i) => (
                        <span
                          key={i}
                          className={`w-1.5 h-1.5 rounded-full inline-block ${
                            i < char.spellSlots ? 'bg-purple-400 ring-1 ring-purple-300' : 'bg-stone-800'
                          }`}
                        />
                      ))}
                    </span>
                  </span>
                ) : (
                  <span className="text-stone-500 font-mono text-[10px]">Martial</span>
                )}

                <span className="text-stone-400 font-mono">
                  STR {formatModifier(getStatModifier(char.stats.str))}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
