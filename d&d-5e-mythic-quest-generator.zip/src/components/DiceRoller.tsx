import React, { useState, useEffect } from 'react';
import { Character, ChoiceOption, DiceRoll } from '../types';
import { getStatModifier, formatModifier } from '../data/presets';
import { soundManager } from '../utils/audio';
import { Dices, Sparkles, Check, X, ShieldAlert } from 'lucide-react';

interface DiceRollerProps {
  choice: ChoiceOption;
  character: Character;
  onRollComplete: (rollResult: DiceRoll) => void;
  onCancel: () => void;
}

export const DiceRoller: React.FC<DiceRollerProps> = ({
  choice,
  character,
  onRollComplete,
  onCancel,
}) => {
  const [advantage, setAdvantage] = useState<'normal' | 'advantage' | 'disadvantage'>('normal');
  const [isRolling, setIsRolling] = useState(false);
  const [displayValue, setDisplayValue] = useState<number>(20);
  const [finalResult, setFinalResult] = useState<DiceRoll | null>(null);

  // Determine applicable stat value
  const statKey = (choice.statReq || 'str') as keyof typeof character.stats;
  const statVal = character.stats[statKey] || 10;
  const modifier = getStatModifier(statVal);

  const handleRoll = () => {
    if (isRolling) return;
    setIsRolling(true);
    soundManager.playDiceRoll();

    // Rapid random numbers animation for 1 second
    let count = 0;
    const interval = setInterval(() => {
      setDisplayValue(Math.floor(Math.random() * 20) + 1);
      count++;
      if (count > 15) {
        clearInterval(interval);

        // Perform real d20 roll
        let d20_1 = Math.floor(Math.random() * 20) + 1;
        let d20_2 = Math.floor(Math.random() * 20) + 1;
        let finalD20 = d20_1;

        if (advantage === 'advantage') {
          finalD20 = Math.max(d20_1, d20_2);
        } else if (advantage === 'disadvantage') {
          finalD20 = Math.min(d20_1, d20_2);
        }

        setDisplayValue(finalD20);
        setIsRolling(false);

        const total = finalD20 + modifier;
        const isSuccess = total >= choice.dc || finalD20 === 20;
        const isCrit = finalD20 === 20;
        const isFail = finalD20 === 1;

        if (isCrit) soundManager.playCrit();
        else if (isSuccess) soundManager.playSuccess();
        else soundManager.playFail();

        const result: DiceRoll = {
          stat: choice.statReq || 'str',
          skill: choice.skillName || 'Ability Check',
          d20: finalD20,
          modifier,
          total,
          dc: choice.dc,
          isSuccess,
          isCrit,
          isFail,
        };

        setFinalResult(result);
      }
    }, 60);
  };

  const handleConfirm = () => {
    if (finalResult) {
      onRollComplete(finalResult);
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-stone-900 border border-amber-800/60 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-6 text-stone-100 relative">
        <div className="text-center">
          <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest bg-amber-950/80 px-3 py-1 rounded-full border border-amber-700/40">
            D&D 5E Skill Check
          </span>
          <h3 className="text-xl font-serif font-bold text-amber-100 mt-2">
            {choice.skillName} Check
          </h3>
          <p className="text-xs text-stone-300 mt-1">
            DC {choice.dc} • {character.name} ({choice.statReq.toUpperCase()} {formatModifier(modifier)})
          </p>
        </div>

        {/* Die Display Circle */}
        <div className="flex flex-col items-center justify-center py-4">
          <div
            onClick={!finalResult ? handleRoll : undefined}
            className={`w-28 h-28 rounded-2xl bg-gradient-to-br from-amber-700 via-amber-800 to-amber-950 border-2 border-amber-400 flex items-center justify-center shadow-2xl cursor-pointer transition-transform ${
              isRolling ? 'scale-110 animate-bounce' : 'hover:scale-105'
            }`}
          >
            <div className="text-center">
              <span className="text-4xl font-serif font-black text-amber-100 drop-shadow-md">
                {displayValue}
              </span>
              <span className="block text-[10px] font-mono text-amber-300 mt-0.5 uppercase">
                d20
              </span>
            </div>
          </div>

          {!finalResult && !isRolling && (
            <p className="text-xs text-amber-400 font-medium mt-3 animate-pulse">
              Tap die or button below to Roll!
            </p>
          )}
        </div>

        {/* Advantage / Disadvantage Selector */}
        {!finalResult && (
          <div className="flex items-center justify-center gap-2 bg-stone-950 p-1.5 rounded-xl border border-stone-800">
            <button
              type="button"
              onClick={() => setAdvantage('normal')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                advantage === 'normal' ? 'bg-amber-600 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              Normal Roll
            </button>
            <button
              type="button"
              onClick={() => setAdvantage('advantage')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                advantage === 'advantage' ? 'bg-emerald-600 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              Advantage
            </button>
            <button
              type="button"
              onClick={() => setAdvantage('disadvantage')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                advantage === 'disadvantage' ? 'bg-red-600 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              Disadvantage
            </button>
          </div>
        )}

        {/* Roll Calculation Output */}
        {finalResult && (
          <div
            className={`p-4 rounded-xl border text-center space-y-2 animate-fadeIn ${
              finalResult.isCrit
                ? 'bg-amber-950 border-amber-400 text-amber-100 ring-2 ring-amber-400/50'
                : finalResult.isSuccess
                ? 'bg-emerald-950/80 border-emerald-700 text-emerald-200'
                : 'bg-red-950/80 border-red-800 text-red-200'
            }`}
          >
            <div className="flex items-center justify-center gap-2 font-serif font-bold text-lg">
              {finalResult.isCrit ? (
                <>
                  <Sparkles className="w-5 h-5 text-amber-300" />
                  CRITICAL HIT! (Natural 20)
                </>
              ) : finalResult.isSuccess ? (
                <>
                  <Check className="w-5 h-5 text-emerald-400" />
                  SUCCESS!
                </>
              ) : (
                <>
                  <X className="w-5 h-5 text-red-400" />
                  CHECK FAILED!
                </>
              )}
            </div>

            <p className="text-xs font-mono">
              d20 ({finalResult.d20}) + {choice.statReq.toUpperCase()} ({formatModifier(finalResult.modifier)}) ={' '}
              <strong className="text-sm font-bold">{finalResult.total}</strong> vs DC {finalResult.dc}
            </p>
          </div>
        )}

        {/* Modal Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {!finalResult ? (
            <>
              <button
                type="button"
                onClick={onCancel}
                disabled={isRolling}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleRoll}
                disabled={isRolling}
                className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold font-serif transition-colors flex items-center gap-1.5 cursor-pointer shadow-lg"
              >
                <Dices className="w-4 h-4" />
                Roll Die
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={handleConfirm}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 text-stone-950 text-xs font-bold font-serif transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xl"
            >
              <Check className="w-4 h-4" />
              Apply Result & Resolve Turn
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
