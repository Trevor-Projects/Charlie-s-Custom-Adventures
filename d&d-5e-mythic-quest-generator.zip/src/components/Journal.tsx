import React, { useState, useEffect } from 'react';
import { GameState, TurnEntry, Character, Milestone } from '../types';
import {
  BookMarked,
  X,
  Sparkles,
  RefreshCw,
  Scroll,
  Shield,
  Trophy,
  Dices,
  Copy,
  Check,
  Award,
  ChevronRight,
  BookOpen,
  Feather,
  Heart,
  Wand2,
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface JournalProps {
  isOpen: boolean;
  onClose: () => void;
  gameState: GameState;
}

interface StoryBeat {
  beatNumber: number;
  chapterTitle: string;
  summary: string;
  keyHighlights: string[];
  heroicQuote?: string;
}

interface JournalSummary {
  title: string;
  overallChronicle: string;
  storyBeats: StoryBeat[];
  partyLegacy: string;
}

export const Journal: React.FC<JournalProps> = ({ isOpen, onClose, gameState }) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'chronicle' | 'timeline' | 'roster'>('chronicle');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [aiSummary, setAiSummary] = useState<JournalSummary | null>(null);
  const [copied, setCopied] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const { history, party, worldName, worldSummary, milestones, currentMilestoneIndex } = gameState;

  // Local fallback chronicle generator if AI isn't called or fails
  const generateLocalChronicle = (): JournalSummary => {
    const totalTurns = history.length;
    const itemsFound = history.flatMap((t) => t.itemsGained || []);
    const crits = history.filter((t) => t.diceRoll?.isCrit);

    const beats: StoryBeat[] = milestones.map((m, idx) => {
      const isPastOrCurrent = idx <= currentMilestoneIndex;
      const matchingTurns = history.filter((_, tIdx) => Math.floor(tIdx / Math.max(1, Math.ceil(totalTurns / Math.max(1, milestones.length)))) === idx);

      let beatSummary = matchingTurns.map((t) => t.narrative).join(' ') || `The heroes embark on Chapter ${m.chapter}: ${m.title}. ${m.description}`;
      if (beatSummary.length > 500) {
        beatSummary = beatSummary.slice(0, 500) + '...';
      }

      const highlights = matchingTurns
        .filter((t) => t.actionText)
        .map((t) => `${t.activePlayerName || 'Hero'} ${t.actionText}`)
        .slice(0, 3);

      if (highlights.length === 0) {
        highlights.push(`Objective: ${m.title}`);
      }

      return {
        beatNumber: idx + 1,
        chapterTitle: `Chapter ${m.chapter}: ${m.title}`,
        summary: isPastOrCurrent ? beatSummary : `(Future Chapter) ${m.description}`,
        keyHighlights: highlights,
        heroicQuote: matchingTurns[0]?.actionText ? `"${matchingTurns[0].actionText}"` : undefined,
      };
    });

    return {
      title: `The Chronicles of ${worldName || 'The Mythic Realm'}`,
      overallChronicle: `In the realm of ${worldName || 'the realm'}, the brave company consisting of ${party.map((p) => p.name).join(', ')} answered the call of destiny. Across ${totalTurns} recorded turns and ${milestones.length} major chapters, they forged their legacy through peril, courage, and cunning.`,
      storyBeats: beats.length > 0 ? beats : [
        {
          beatNumber: 1,
          chapterTitle: 'Chapter 1: The Inciting Incident',
          summary: history[0]?.narrative || 'The journey begins in mystery and danger.',
          keyHighlights: ['Campaign Commenced', ...itemsFound],
        },
      ],
      partyLegacy: `${party.length} heroes stand united, ready to confront whatever dark powers threaten the land.`,
    };
  };

  const currentChronicle = aiSummary || generateLocalChronicle();

  const handleFetchAiSummary = async () => {
    setIsSummarizing(true);
    setSummaryError(null);
    soundManager.playDiceRoll();

    try {
      const res = await fetch('/api/summarize-journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          worldName,
          worldSummary,
          party,
          history,
          milestones,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to weave AI chronicle.');
      }

      const data: JournalSummary = await res.json();
      setAiSummary(data);
      soundManager.playSuccess();
    } catch (err: any) {
      console.error('Journal AI summary error:', err);
      setSummaryError('Could not connect to AI Bard. Displaying compiled history log.');
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleCopyText = () => {
    soundManager.playPageTurn();
    const formatted = `=== ${currentChronicle.title} ===\n\n${currentChronicle.overallChronicle}\n\n` +
      currentChronicle.storyBeats
        .map((b) => `${b.chapterTitle}\n${b.summary}\nHighlights: ${b.keyHighlights.join(' • ')}`)
        .join('\n\n') +
      `\n\nLegacy: ${currentChronicle.partyLegacy}`;

    navigator.clipboard.writeText(formatted);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-stone-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="bg-stone-900 border border-amber-800/70 rounded-2xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl text-stone-100 relative max-h-[90vh] flex flex-col justify-between overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-amber-200 rounded-lg hover:bg-stone-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="border-b border-amber-800/50 pb-4 mb-4 flex items-center justify-between pr-8">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-950/80 rounded-xl border border-amber-700/60 text-amber-300 shadow-inner">
              <BookMarked className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1">
                <Feather className="w-3 h-3 text-amber-400" /> Grand Campaign Chronicle
              </span>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-amber-100">
                {worldName || 'The Heroic Annals'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCopyText}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-200 border border-stone-700 text-xs font-bold transition-all cursor-pointer"
            title="Copy formatted journal text to clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copied ? 'Copied!' : 'Copy Journal'}</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-stone-800 mb-4 bg-stone-950/60 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => {
              soundManager.playPageTurn();
              setActiveTab('chronicle');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold font-serif transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'chronicle'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Scroll className="w-3.5 h-3.5" />
            <span>Story Chronicle</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playPageTurn();
              setActiveTab('timeline');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold font-serif transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'timeline'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Dices className="w-3.5 h-3.5" />
            <span>Turn Log ({history.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playPageTurn();
              setActiveTab('roster');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold font-serif transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'roster'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Party Roster</span>
          </button>
        </div>

        {/* Tab 1: Formatted Story Chronicle */}
        {activeTab === 'chronicle' && (
          <div className="flex-1 overflow-y-auto space-y-5 pr-1">
            {/* AI Summarize Action Banner */}
            <div className="bg-stone-950 p-4 rounded-xl border border-amber-800/40 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
              <div className="space-y-1 text-center sm:text-left">
                <h4 className="text-xs font-serif font-bold text-amber-200 flex items-center justify-center sm:justify-start gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  AI Bard Chronicle Synthesizer
                </h4>
                <p className="text-[11px] text-stone-400 leading-tight">
                  Automatically summarize turns & major narrative arcs into an epic prose saga.
                </p>
              </div>

              <button
                type="button"
                onClick={handleFetchAiSummary}
                disabled={isSummarizing}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold font-serif transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0 shadow-lg shadow-amber-600/20"
              >
                {isSummarizing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-stone-950" />
                    <span>Weaving Saga...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>{aiSummary ? 'Re-Weave AI Journal' : 'Summarize with AI'}</span>
                  </>
                )}
              </button>
            </div>

            {summaryError && (
              <div className="p-3 bg-red-950/60 border border-red-800 rounded-xl text-red-200 text-xs">
                {summaryError}
              </div>
            )}

            {/* Overall Saga Summary */}
            <div className="bg-amber-950/20 border border-amber-900/40 p-5 rounded-2xl space-y-3 font-serif">
              <h3 className="text-xl font-bold text-amber-100 flex items-center gap-2 border-b border-amber-800/30 pb-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                {currentChronicle.title}
              </h3>
              <p className="text-stone-200 text-sm leading-relaxed italic">
                "{currentChronicle.overallChronicle}"
              </p>
            </div>

            {/* Story Beats / Narrative Arcs */}
            <div className="space-y-4">
              <h4 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-amber-400" /> Major Narrative Beats & Chapters
              </h4>

              {currentChronicle.storyBeats.map((beat) => (
                <div
                  key={beat.beatNumber}
                  className="bg-stone-950 p-4 rounded-xl border border-stone-800 space-y-3 shadow-md"
                >
                  <div className="flex items-center justify-between border-b border-stone-800/80 pb-2">
                    <h5 className="font-serif font-bold text-base text-amber-200 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-amber-950 border border-amber-700 text-amber-300 text-xs flex items-center justify-center font-mono font-bold">
                        {beat.beatNumber}
                      </span>
                      {beat.chapterTitle}
                    </h5>
                  </div>

                  <p className="text-stone-300 text-xs sm:text-sm leading-relaxed font-serif">
                    {beat.summary}
                  </p>

                  {beat.heroicQuote && (
                    <blockquote className="border-l-2 border-amber-500 pl-3 italic text-xs text-amber-200 font-serif">
                      {beat.heroicQuote}
                    </blockquote>
                  )}

                  {beat.keyHighlights && beat.keyHighlights.length > 0 && (
                    <div className="pt-2 border-t border-stone-900 flex flex-wrap gap-1.5">
                      {beat.keyHighlights.map((hl, hIdx) => (
                        <span
                          key={hIdx}
                          className="text-[11px] px-2.5 py-0.5 rounded-full bg-stone-900 border border-stone-800 text-amber-300/90 font-mono"
                        >
                          ✨ {hl}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Party Legacy Statement */}
            <div className="bg-stone-950 p-4 rounded-xl border border-amber-800/50 text-center space-y-1">
              <span className="text-[10px] text-amber-400 font-mono font-bold uppercase tracking-widest">
                Party Standing & Reputation
              </span>
              <p className="text-xs text-stone-200 italic font-serif">
                "{currentChronicle.partyLegacy}"
              </p>
            </div>
          </div>
        )}

        {/* Tab 2: Turn Timeline Log */}
        {activeTab === 'timeline' && (
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            <p className="text-xs text-stone-400 mb-2">
              Chronological turn-by-turn history log of party actions and outcomes:
            </p>

            {history.map((turn, index) => (
              <div
                key={turn.id || index}
                className="bg-stone-950 p-3.5 rounded-xl border border-stone-800 text-xs space-y-2"
              >
                <div className="flex items-center justify-between text-[11px] text-stone-400 font-mono border-b border-stone-900 pb-1.5">
                  <span className="font-bold text-amber-400">
                    Turn {index + 1} • {turn.activePlayerName || 'Party'}
                  </span>
                  <span>{turn.timestamp}</span>
                </div>

                {turn.actionText && (
                  <p className="font-semibold text-amber-200">
                    Action: "{turn.actionText}"
                  </p>
                )}

                <p className="text-stone-300 font-serif leading-relaxed line-clamp-3">
                  {turn.narrative}
                </p>

                {turn.diceRoll && (
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-stone-900 text-amber-300 border border-stone-800 font-mono text-[10px]">
                    <Dices className="w-3 h-3 text-amber-400" />
                    <span>
                      {turn.diceRoll.skill}: Rolled {turn.diceRoll.total} (DC {turn.diceRoll.dc})
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Party Roster */}
        {activeTab === 'roster' && (
          <div className="flex-1 overflow-y-auto space-y-4 pr-1">
            <p className="text-xs text-stone-400">
              Active party members embarking on this campaign:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {party.map((char) => (
                <div
                  key={char.id}
                  className="bg-stone-950 p-4 rounded-xl border border-stone-800 flex gap-3 items-start"
                >
                  {char.portraitUrl ? (
                    <img
                      src={char.portraitUrl}
                      alt={char.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-xl object-cover border border-amber-500/80 bg-stone-900 shrink-0"
                    />
                  ) : (
                    <span className="text-3xl p-2 bg-stone-900 rounded-xl border border-stone-800 shrink-0">
                      {char.avatar}
                    </span>
                  )}

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between">
                      <h5 className="font-serif font-bold text-amber-100 text-sm truncate">
                        {char.name}
                      </h5>
                      <span className="text-[10px] font-mono text-amber-400 font-bold">
                        Lvl {char.level}
                      </span>
                    </div>

                    <p className="text-xs text-stone-400 truncate">
                      {char.race} {char.characterClass}
                    </p>

                    <div className="flex items-center gap-3 text-xs font-mono pt-1">
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Heart className="w-3 h-3" /> {char.hp}/{char.maxHp} HP
                      </span>
                      {char.maxSpellSlots > 0 && (
                        <span className="text-purple-300 flex items-center gap-1">
                          <Wand2 className="w-3 h-3" /> {char.spellSlots}/{char.maxSpellSlots}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="border-t border-amber-800/40 pt-4 mt-4 flex items-center justify-between text-xs">
          <span className="text-stone-400 font-mono text-[11px]">
            {history.length} Turn Entries • Chapter {currentMilestoneIndex + 1} of {milestones.length}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold font-serif transition-colors cursor-pointer shadow-md"
          >
            Close Journal
          </button>
        </div>
      </div>
    </div>
  );
};
